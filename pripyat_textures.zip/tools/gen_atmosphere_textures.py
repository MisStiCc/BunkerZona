# -*- coding: utf-8 -*-
"""Generate procedural decals / signs for the gloomy STALKER atmosphere
(tileable-friendly, transparent PNGs) -> godot/textures/decals/.

Everything here is original procedural art (no external licenses attached).
"""
import math
import os
import random

import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT_DIR = os.path.join(ROOT, "godot", "textures", "decals")
S = 512


def periodic_noise(size, octaves=(2, 3, 5, 7, 11), weights=None, seed=0):
    """Perfectly tileable fractal noise in [0,1] (sum of integer-frequency waves)."""
    rng = np.random.default_rng(seed)
    weights = weights or [1.0 / (i + 1) for i in range(len(octaves))]
    xs = np.linspace(0, 1, size, endpoint=False)
    X, Y = np.meshgrid(xs, xs)
    acc = np.zeros((size, size))
    for f, w in zip(octaves, weights):
        kx, ky = rng.integers(1, max(2, f)), rng.integers(1, max(2, f))
        phase = rng.uniform(0, 2 * math.pi)
        acc += w * np.sin(2 * math.pi * (kx * X + ky * Y) + phase)
        phase2 = rng.uniform(0, 2 * math.pi)
        acc += w * np.sin(2 * math.pi * (kx * X - ky * Y) + phase2)
    acc -= acc.min()
    acc /= acc.max() + 1e-9
    return acc


def save(img, name):
    os.makedirs(OUT_DIR, exist_ok=True)
    img.save(os.path.join(OUT_DIR, name), optimize=True)
    print("  +", name)


# ---------------------------------------------------------------- cracks ---

def gen_crack(seed, name):
    rng = random.Random(seed)
    img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    dark = (25, 22, 20)
    light = (95, 90, 82)

    def walk(x, y, angle, steps, width, depth):
        for _ in range(steps):
            nx = x + math.cos(angle) * 6
            ny = y + math.sin(angle) * 6
            d.line([(x, y), (nx, ny)], fill=dark + (int(230 * depth),), width=width)
            d.line([(x, y - 1), (nx, ny - 1)], fill=light + (int(90 * depth),), width=1)
            x, y = nx, ny
            angle += rng.uniform(-0.45, 0.45)
            if rng.random() < 0.06 and depth > 0.4:
                walk(x, y, angle + rng.choice([-1, 1]) * rng.uniform(0.6, 1.2),
                     int(steps * 0.5), max(1, width - 1), depth * 0.6)
            if not (0 <= x < S and 0 <= y < S):
                return

    start_angle = rng.uniform(0, 2 * math.pi)
    walk(rng.randint(60, S - 60), rng.randint(60, S - 60), start_angle, 70, 3, 1.0)
    img = img.filter(ImageFilter.GaussianBlur(0.6))
    # erode edges with noise so it's not a vector-perfect line
    alpha = np.asarray(img).copy()
    n = periodic_noise(S, seed=seed + 1)
    mask = (alpha[..., 3] > 0)
    alpha[..., 3] = np.where(mask, (alpha[..., 3] * (0.75 + 0.25 * n)).astype(np.uint8), 0)
    save(Image.fromarray(alpha), name)


# ------------------------------------------------------------ rust streaks ---

def gen_rust_streak(seed, name):
    rng = np.random.default_rng(seed)
    base = np.zeros((S, S, 4), dtype=np.uint8)
    for _ in range(rng.integers(5, 9)):
        x0 = rng.uniform(0.1, 0.9) * S
        w = rng.uniform(6, 26)
        length = rng.uniform(0.5, 1.0) * S
        col_a = np.array([b for b in (rng.integers(120, 175), rng.integers(60, 95), rng.integers(28, 48))])
        col_b = np.array([b for b in (rng.integers(70, 100), rng.integers(38, 55), rng.integers(20, 32))])
        xs = np.arange(S)
        for y in range(int(length)):
            t = y / length
            jitter = math.sin(y * 0.15 + seed) * 4
            cx = x0 + jitter + t * rng.uniform(-10, 10)
            for x in range(int(cx - w * t), int(cx + w * t)):
                if 0 <= x < S:
                    fall = 1.0 - abs(x - cx) / max(w * t, 1)
                    a = int(200 * fall * (1.0 - t) ** 0.7)
                    if a > base[y, x, 3]:
                        c = (col_a * (1 - t) + col_b * t).astype(int)
                        base[y, x] = (int(c[0]), int(c[1]), int(c[2]), a)
    img = Image.fromarray(base, "RGBA").filter(ImageFilter.GaussianBlur(1.2))
    arr = np.asarray(img).copy()
    n = periodic_noise(S, seed=seed + 2)
    arr[..., 3] = (arr[..., 3] * (0.6 + 0.4 * n)).astype(np.uint8)
    save(Image.fromarray(arr), name)


# ----------------------------------------------------------------- stains ---

def gen_stain(seed, name, color=(58, 52, 44)):
    rng = np.random.default_rng(seed)
    field = np.zeros((S, S))
    for _ in range(rng.integers(3, 6)):
        cx, cy = rng.uniform(0.25, 0.75) * S, rng.uniform(0.25, 0.75) * S
        r = rng.uniform(60, 190)
        y, x = np.ogrid[:S, :S]
        field += np.exp(-((x - cx) ** 2 + (y - cy) ** 2) / (2 * r * r))
    field /= field.max()
    n = periodic_noise(S, seed=seed + 3)
    alpha = np.clip((field - 0.28) * 1.9, 0, 1) * (0.55 + 0.45 * n)
    shade = (0.65 + 0.35 * n)
    arr = np.zeros((S, S, 4), dtype=np.uint8)
    for i, c in enumerate(color):
        arr[..., i] = (c * shade).astype(np.uint8)
    arr[..., 3] = (alpha * 215).astype(np.uint8)
    save(Image.fromarray(arr, "RGBA").filter(ImageFilter.GaussianBlur(1.5)), name)


# ------------------------------------------------------------- moss patch ---

def gen_moss(seed, name):
    rng = np.random.default_rng(seed)
    field = np.zeros((S, S))
    for _ in range(4):
        cx, cy = rng.uniform(0.3, 0.7) * S, rng.uniform(0.3, 0.7) * S
        r = rng.uniform(80, 170)
        y, x = np.ogrid[:S, :S]
        field += np.exp(-((x - cx) ** 2 + (y - cy) ** 2) / (2 * r * r))
    field /= field.max()
    n1 = periodic_noise(S, octaves=(3, 5, 9, 13), seed=seed + 4)
    n2 = periodic_noise(S, octaves=(2, 4, 7), seed=seed + 5)
    alpha = np.clip((field * (0.5 + 0.7 * n1) - 0.34) * 2.2, 0, 1)
    g = np.clip(0.35 + 0.5 * n2, 0, 1)
    r_ = g * 0.45 + 0.05
    b_ = g * 0.28 + 0.03
    arr = np.zeros((S, S, 4), dtype=np.uint8)
    arr[..., 0] = (r_ * 255).astype(np.uint8)
    arr[..., 1] = (g * 175).astype(np.uint8)
    arr[..., 2] = (b_ * 255).astype(np.uint8)
    arr[..., 3] = (alpha * 230).astype(np.uint8)
    save(Image.fromarray(arr, "RGBA").filter(ImageFilter.GaussianBlur(1.0)), name)


# ------------------------------------------------------------ bullet holes ---

def gen_bullet_hole(seed, name):
    rng = random.Random(seed)
    img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    cx, cy = S // 2 + rng.randint(-30, 30), S // 2 + rng.randint(-30, 30)
    d.ellipse([cx - 14, cy - 14, cx + 14, cy + 14], fill=(20, 17, 15, 255))
    d.ellipse([cx - 7, cy - 7, cx + 7, cy + 7], fill=(8, 7, 6, 255))
    for _ in range(rng.randint(7, 11)):
        ang = rng.uniform(0, 2 * math.pi)
        ln = rng.uniform(20, 70)
        x2 = cx + math.cos(ang) * ln
        y2 = cy + math.sin(ang) * ln
        d.line([(cx + math.cos(ang) * 10, cy + math.sin(ang) * 10), (x2, y2)],
               fill=(35, 31, 28, rng.randint(120, 200)), width=rng.randint(2, 4))
    for _ in range(rng.randint(14, 22)):
        ang = rng.uniform(0, 2 * math.pi)
        r0 = rng.uniform(16, 60)
        rr = rng.uniform(2, 6)
        x0 = cx + math.cos(ang) * r0
        y0 = cy + math.sin(ang) * r0
        d.ellipse([x0 - rr, y0 - rr, x0 + rr, y0 + rr],
                  fill=(45, 40, 36, rng.randint(90, 170)))
    img = img.filter(ImageFilter.GaussianBlur(0.8))
    arr = np.asarray(img).copy()
    n = periodic_noise(S, seed=seed + 6)
    arr[..., 3] = (arr[..., 3] * (0.8 + 0.2 * n)).astype(np.uint8)
    save(Image.fromarray(arr), name)


# -------------------------------------------------------- radiation sign ----

def gen_radiation_sign(name):
    img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle([16, 16, S - 16, S - 16], radius=28,
                        fill=(198, 164, 34, 255), outline=(30, 27, 24, 255), width=6)
    cx = cy = S // 2
    R = 150
    d.ellipse([cx - R, cy - R, cx + R, cy + R], outline=(25, 23, 21, 255), width=7)
    d.ellipse([cx - 24, cy - 24, cx + 24, cy + 24], fill=(25, 23, 21, 255))
    for k in range(3):
        a0 = math.radians(-90 + k * 120 - 28)
        a1 = math.radians(-90 + k * 120 + 28)
        d.pieslice([cx - R + 18, cy - R + 18, cx + R - 18, cy + R - 18],
                   math.degrees(a0), math.degrees(a1), fill=(25, 23, 21, 255))
    try:
        font = ImageFont.truetype("C:/Windows/Fonts/arialbd.ttf", 44)
        d.text((cx, S - 58), "РАДІАЦІЯ", font=font, fill=(25, 23, 21, 255), anchor="mm")
    except OSError:
        pass
    # wear: erosion + scratches + darkened edges
    arr = np.asarray(img).astype(np.float32)
    n = periodic_noise(S, octaves=(2, 5, 9, 17), seed=42)
    dirt = periodic_noise(S, octaves=(3, 7), seed=43)
    alpha = arr[..., 3] * np.clip(0.55 + 0.75 * n, 0, 1)
    arr[..., 3] = np.clip(alpha, 0, 255)
    arr[..., :3] *= (0.72 + 0.28 * dirt)[..., None]
    arr[..., 1] *= 0.94  # yellowing -> duller
    img = Image.fromarray(arr.astype(np.uint8), "RGBA")
    d = ImageDraw.Draw(img)
    rng = random.Random(7)
    for _ in range(26):
        x0, y0 = rng.randint(0, S), rng.randint(0, S)
        x1 = x0 + rng.randint(-70, 70)
        y1 = y0 + rng.randint(-70, 70)
        d.line([(x0, y0), (x1, y1)], fill=(120, 100, 50, rng.randint(40, 90)),
               width=rng.randint(1, 3))
    save(img, name)


# ---------------------------------------------------------- hazard stripes ---

def gen_hazard_stripes(name):
    img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    stripe = 64
    for i in range(-S, S * 2, stripe * 2):
        d.polygon([(i, S), (i + S, 0), (i + S + stripe, 0), (i + stripe, S)],
                  fill=(190, 158, 38, 255))
    dark = Image.new("RGBA", (S, S), (28, 25, 22, 255))
    mask = Image.new("L", (S, S), 0)
    dm = ImageDraw.Draw(mask)
    for i in range(-S, S * 2, stripe * 2):
        dm.polygon([(i + stripe, S), (i + S + stripe, 0), (i + S + stripe * 2, 0), (i + stripe * 2, S)], fill=255)
    img = Image.composite(dark, img, mask)
    arr = np.asarray(img).astype(np.float32)
    n = periodic_noise(S, octaves=(3, 6, 11, 23), seed=11)
    arr[..., 3] = np.clip(arr[..., 3] * (0.55 + 0.6 * n), 0, 255)
    arr[..., :3] *= (0.7 + 0.3 * periodic_noise(S, seed=12))[..., None]
    save(Image.fromarray(arr.astype(np.uint8), "RGBA"), name)


# ------------------------------------------------------------ paint marks ----

def gen_paint_mark(seed, name, shape="x"):
    rng = random.Random(seed)
    img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    col = (215, 210, 195, 255) if shape == "x" else (200, 170, 60, 255)
    w = 34
    if shape == "x":
        d.line([(80, 80), (S - 80, S - 80)], fill=col, width=w)
        d.line([(S - 80, 80), (80, S - 80)], fill=col, width=w)
    elif shape == "arrow":
        d.line([(90, S // 2), (S - 110, S // 2)], fill=col, width=w)
        d.polygon([(S - 160, S // 2 - 70), (S - 60, S // 2), (S - 160, S // 2 + 70)], fill=col)
    arr = np.asarray(img).astype(np.float32)
    n = periodic_noise(S, octaves=(2, 5, 13), seed=seed + 8)
    # worn paint: strong erosion threshold
    arr[..., 3] = np.clip(arr[..., 3] * np.clip((n - 0.28) * 2.6, 0, 1), 0, 255)
    img = Image.fromarray(arr.astype(np.uint8), "RGBA").filter(ImageFilter.GaussianBlur(1.0))
    d = ImageDraw.Draw(img)
    for _ in range(rng.randint(8, 14)):
        x0 = rng.randint(0, S)
        y0 = rng.randint(0, S)
        d.line([(x0, y0), (x0 + rng.randint(-60, 60), y0 + rng.randint(-60, 60))],
               fill=(150, 145, 130, rng.randint(25, 60)), width=2)
    save(img, name)


def main():
    print("generating decals ->", OUT_DIR)
    for i, seed in enumerate([1, 2, 3]):
        gen_crack(seed, f"crack_{i+1:02d}.png")
    gen_rust_streak(10, "rust_streak_01.png")
    gen_rust_streak(11, "rust_streak_02.png")
    gen_stain(20, "stain_dark_01.png", color=(58, 52, 44))
    gen_stain(21, "stain_dark_02.png", color=(48, 44, 38))
    gen_stain(22, "stain_oil_01.png", color=(30, 28, 26))
    gen_moss(30, "moss_patch_01.png")
    gen_moss(31, "moss_patch_02.png")
    gen_bullet_hole(40, "bullet_holes_01.png")
    gen_bullet_hole(41, "bullet_holes_02.png")
    gen_radiation_sign("sign_radiation.png")
    gen_hazard_stripes("hazard_stripes.png")
    gen_paint_mark(50, "paint_x_white.png", "x")
    gen_paint_mark(51, "paint_arrow_yellow.png", "arrow")


if __name__ == "__main__":
    main()
