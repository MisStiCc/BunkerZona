# -*- coding: utf-8 -*-
"""Download the curated CC0 PBR texture pack from ambientCG for the
STALKER-style atmosphere, normalise maps and lay them out for Godot.

Output: godot/textures/pbr/<category>/{albedo,normal,roughness,ao,displacement}.png
        textures/pack_preview.png (contact sheet)
        godot/materials/<category>.tres (ready StandardMaterial3D)

All ambientCG assets are CC0 (public domain).
"""
import io
import json
import os
import shutil
import urllib.request
import zipfile

from PIL import Image

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PBR_DIR = os.path.join(ROOT, "godot", "textures", "pbr")
MAT_DIR = os.path.join(ROOT, "godot", "materials")
PREVIEW_PATH = os.path.join(ROOT, "textures", "pack_preview.png")

UA = {"User-Agent": "Mozilla/5.0 (pripyat-godot-map/1.0)"}

# category -> (ambientCG asset id, optional desaturation 0..1 for mood tuning)
SELECTION = {
    "asphalt_worn":      ("Asphalt022", 0.15),
    "asphalt_old":       ("Asphalt006", 0.15),
    "concrete_wall_dirty": ("Concrete037", 0.15),
    "concrete_wall_clean": ("Concrete036", 0.10),
    "concrete_floor":    ("Concrete041A", 0.15),
    "brick_dark":        ("Bricks091", 0.20),
    "rust_heavy":        ("Rust005", 0.0),
    "corrugated_rust":   ("CorrugatedSteel005", 0.0),
    "corrugated_metal":  ("CorrugatedSteel002", 0.25),
    "dirt_dry":          ("Ground063", 0.20),
    "gravel_dirty":      ("Gravel025", 0.15),
    "gravel_fine":       ("Gravel015", 0.15),
    "dead_grass":        ("Grass005", 0.45),   # kill the green -> Zone overgrowth
    "wood_planks_old":   ("Planks035A", 0.20),
    "plaster_cracked":   ("Plaster007", 0.15),
    "moss":              ("Moss002", 0.10),
    "leak_stains":       ("Leaking004", 0.0),
    "leak_stains_2":     ("Leaking002", 0.0),
}

MAP_SUFFIXES = {
    "Color": "albedo",
    "NormalGL": "normal",    # already OpenGL Y-up
    "NormalDX": None,        # ignored, NormalGL preferred
    "Roughness": "roughness",
    "AmbientOcclusion": "ao",
    "Displacement": "displacement",
    "Metalness": "metalness",
}


def fetch(url: str, timeout: int = 120) -> bytes:
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def desaturate(im: Image.Image, amount: float) -> Image.Image:
    if amount <= 0:
        return im
    g = im.convert("L").convert("RGB")
    return Image.blend(im, g, amount)


def process_asset(category: str, asset_id: str, desat: float) -> dict:
    out_dir = os.path.join(PBR_DIR, category)
    done_flag = os.path.join(out_dir, ".done")
    if os.path.exists(done_flag):
        print(f"[skip] {category} (already done)")
        return {"category": category, "asset": asset_id, "cached": True}

    url = f"https://ambientcg.com/get?file={asset_id}_1K-JPG.zip"
    print(f"[get ] {category} <- {asset_id} ...")
    blob = fetch(url)
    zf = zipfile.ZipFile(io.BytesIO(blob))

    os.makedirs(out_dir, exist_ok=True)
    got = {}
    for name in zf.namelist():
        base = os.path.basename(name)
        if not base or base.endswith("/"):
            continue
        for suffix, out_name in MAP_SUFFIXES.items():
            if out_name is None:
                continue
            if base == f"{asset_id}_1K-JPG_{suffix}.jpg":
                got[out_name] = zf.read(name)
                break

    for out_name, data in got.items():
        im = Image.open(io.BytesIO(data)).convert("RGB")
        if out_name == "albedo":
            im = desaturate(im, desat)
        im.save(os.path.join(out_dir, f"{out_name}.png"), optimize=True)

    with open(done_flag, "w") as f:
        f.write(f"{asset_id}\n")
    print(f"[ok  ] {category}: {sorted(got)}")
    return {"category": category, "asset": asset_id, "maps": sorted(got)}


def write_material_tres(category: str, uv_scale: float = 0.25) -> None:
    """StandardMaterial3D wired to the downloaded maps (tiling via uv1_scale)."""
    maps = {
        "albedo": "albedo.png",
        "normal": "normal.png",
        "roughness": "roughness.png",
        "ao": "ao.png",
        "metalness": "metalness.png",
    }
    have = {k: v for k, v in maps.items()
            if os.path.exists(os.path.join(PBR_DIR, category, v))}
    lines = [
        "[gd_resource type=\"StandardMaterial3D\" load_steps=%d format=3]" % (len(have) + 1),
    ]
    n = 1
    tex_ids = {}
    for key in maps:
        if key not in have:
            continue
        n += 1
        tex_ids[key] = str(n)
        path = f"res://textures/pbr/{category}/{have[key]}"
        if key in ("normal", "roughness"):
            lines.append(f"[ext_resource type=\"Texture2D\" path=\"{path}\" id=\"{tex_ids[key]}\"]")
        else:
            lines.append(f"[ext_resource type=\"Texture2D\" path=\"{path}\" id=\"{tex_ids[key]}\"]")
    res = ["[resource]", "albedo_color = Color(0.85, 0.85, 0.85, 1)",
           "roughness = 1.0", "uv1_scale = Vector3(%g, %g, %g)" % (uv_scale, uv_scale, uv_scale)]
    if "albedo" in tex_ids:
        res.append("albedo_texture = ExtResource(\"%s\")" % tex_ids["albedo"])
    if "normal" in tex_ids:
        res.append("normal_enabled = true")
        res.append("normal_texture = ExtResource(\"%s\")" % tex_ids["normal"])
    if "roughness" in tex_ids:
        res.append("roughness_texture = ExtResource(\"%s\")" % tex_ids["roughness"])
    if "metalness" in tex_ids:
        res.append("metallic = 1.0")
        res.append("metallic_texture = ExtResource(\"%s\")" % tex_ids["metalness"])
    lines.extend(res)
    os.makedirs(MAT_DIR, exist_ok=True)
    with open(os.path.join(MAT_DIR, f"{category}.tres"), "w", encoding="utf-8") as f:
        f.write("\n\n".join(lines) + "\n")


def contact_sheet() -> None:
    cats = sorted(d for d in os.listdir(PBR_DIR)
                  if os.path.isdir(os.path.join(PBR_DIR, d)))
    cell, label_h = 256, 24
    cols = 6
    rows = (len(cats) + cols - 1) // cols
    sheet = Image.new("RGB", (cols * cell, rows * (cell + label_h)), (24, 24, 24))
    from PIL import ImageDraw, ImageFont
    d = ImageDraw.Draw(sheet)
    try:
        font = ImageFont.truetype("C:/Windows/Fonts/arial.ttf", 15)
    except OSError:
        font = ImageFont.load_default()
    for i, cat in enumerate(cats):
        p = os.path.join(PBR_DIR, cat, "albedo.png")
        if not os.path.exists(p):
            continue
        im = Image.open(p).convert("RGB")
        im.thumbnail((cell, cell))
        x, y = (i % cols) * cell, (i // cols) * (cell + label_h)
        sheet.paste(im, (x + (cell - im.width) // 2, y + (cell - im.height) // 2))
        d.text((x + 4, y + cell + 2), cat, font=font, fill=(235, 235, 235))
    os.makedirs(os.path.dirname(PREVIEW_PATH), exist_ok=True)
    sheet.save(PREVIEW_PATH, quality=85)
    print("contact sheet:", PREVIEW_PATH, sheet.size)


def main():
    manifest = {"source": "ambientCG.com", "license": "CC0 1.0 (public domain)",
                "textures": []}
    for category, (asset_id, desat) in SELECTION.items():
        info = process_asset(category, asset_id, desat)
        manifest["textures"].append(info)
        write_material_tres(category)
    with open(os.path.join(PBR_DIR, "manifest.json"), "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2, ensure_ascii=False)
    contact_sheet()


if __name__ == "__main__":
    main()
