# Архив 2 — Пакет текстур «мрачная атмосфера» (STALKER-style)

Библиотека текстур для заброшенной зоны отчуждения. Распаковать **поверх
архива карты** (структура `godot/…` совмещается) или использовать как
самостоятельный набор ассетов в любом движке.

## Состав архива

```
godot/textures/pbr/<категория>/    18 CC0 материалов, полные наборы карт:
       albedo.jpg, normal.png (OpenGL), roughness.jpg, ao.jpg,
       displacement.jpg, metalness.jpg (для металлов)
       manifest.json — источник и лицензия каждой категории
godot/materials/<категория>.tres    18 готовых StandardMaterial3D (3D)
godot/textures/decals/              16 прозрачных PNG 512×512 (процедурные)
godot/scenes/textures_demo.tscn     демо-сцена: сетка 3×3 тайлов + подписи
godot/scripts/texture_demo.gd
tools/fetch_textures.py             (пере)загрузка CC0 материалов ambientCG
tools/gen_atmosphere_textures.py    генератор декалей (оригинальные)
textures/pack_preview.png           контактный лист материалов
textures/decals_preview.png         контактный лист декалей
```

## Материалы (весь список CC0 с ambientCG, приглушены под «зону»)

| Категория | Что это |
|---|---|
| asphalt_worn / asphalt_old | потёртый и старый растрескавшийся асфальт |
| concrete_floor | бетонные плиты пола |
| gravel_dirty / gravel_fine | крупный грязный и мелкий гравий |
| dirt_dry | сухая потрескавшаяся земля |
| dead_grass | сухая жёлто-бурая трава (перекрашена из зелёной) |
| concrete_wall_dirty / clean | грязные и относительно чистые бетонные панели |
| brick_dark | тёмный состаренный кирпич |
| plaster_cracked | потрескавшаяся штукатурка |
| wood_planks_old | старые деревянные доски |
| corrugated_metal / corrugated_rust | профнастил чистый и ржавый |
| rust_heavy | сплошная ржавчина |
| moss | мох |
| leak_stains / leak_stains_2 | потёки и протечки на стенах |

Материалы `.tres` используют `uv1_scale` для тайлинга; подберите масштаб
под размер объекта (1 ед. Godot = 1 м).

## Декали (прозрачные, генератор — tools/gen_atmosphere_textures.py)

crack_01..03 (трещины), rust_streak_01..02 (ржавые потёки),
stain_dark_01..02 (тёмные пятна), stain_oil_01 (масло),
moss_patch_01..02 (мох), bullet_holes_01..02 (пулевые отверстия),
sign_radiation (знак «Радіація»), hazard_stripes (жёлто-чёрные полосы),
paint_x_white / paint_arrow_yellow (истёршаяся краска).

Декали уже подключены к карте: `scripts/grime_spawner.gd` в архиве карты
рассыпает их по зоне (420 по умолчанию, регулируется в инспекторе).

## Замена и пополнение

1. Найдите материал на ambientcg.com (CC0), скопируйте ID (напр. `Mud004`).
2. Добавьте строку в таблицу `SELECTION` в `tools/fetch_textures.py`:
   `"my_mud": ("Mud004", 0.15),`  (второе число — десатурация 0..1).
3. `python tools/fetch_textures.py` — скачает, обработает (normal -> OpenGL,
   приглушение) и соберёт `.tres` + контактный лист.
4. `python tools/gen_atmosphere_textures.py` — перегенерация декалей.

## Лицензия

- ambientCG — CC0 1.0 (общественное достояние): можно использовать в
  коммерческих проектах без атрибуции (упомянуть источник — вежливо).
- Декали и генераторы — оригинальные процедурные, без ограничений.
