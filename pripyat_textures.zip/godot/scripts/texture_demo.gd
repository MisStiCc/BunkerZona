@tool
extends Node2D
## Runtime browser for the texture pack: tiles every PBR albedo 3x3 in a grid
## and lists decals below, with name labels. Open scenes/textures_demo.tscn.

@export var cell_m := 5.0        # world-metre size of one preview cell
@export var columns := 6
@export var pbr_dir := "res://textures/pbr"
@export var decals_dir := "res://textures/decals"


func _ready() -> void:
	_build()


## Works both with imported resources and raw files (fresh checkout, no import).
static func _load_texture(path: String) -> Texture2D:
	if ResourceLoader.exists(path) and FileAccess.file_exists(path + ".import"):
		var t: Texture2D = load(path)
		if t != null:
			return t
	if FileAccess.file_exists(path):
		var img := Image.load_from_file(path)
		if img != null:
			return ImageTexture.create_from_image(img)
	return null


func _build() -> void:
	var label_font_size := 24

	var entries: Array = []
	var dir := DirAccess.open(pbr_dir)
	if dir:
		dir.list_dir_begin()
		var cname := dir.get_next()
		while cname != "":
			for ext in ["jpg", "png"]:
				var tex := _load_texture(pbr_dir.path_join(cname).path_join("albedo." + ext))
				if tex != null:
					entries.append({"name": cname, "tex": tex})
					break
			cname = dir.get_next()
	entries.sort_custom(func(a, b): return String(a.name) < String(b.name))

	var i := 0
	for entry in entries:
		var sprite := Sprite2D.new()
		var t: Texture2D = entry.tex
		sprite.texture = t
		sprite.texture_repeat = CanvasItem.TEXTURE_REPEAT_ENABLED
		sprite.region_enabled = true
		# tile the 1K texture 3x3 inside the cell
		sprite.region_rect = Rect2(0, 0, t.get_width() * 3.0, t.get_height() * 3.0)
		sprite.scale = Vector2.ONE * (cell_m * 3.0 / (t.get_width() * 3.0))
		var col := i % columns
		var row := i / columns
		sprite.position = _cell_pos(col, row, cell_m)
		add_child(sprite)

		_label(String(entry.name), sprite.position + Vector2(0, cell_m * 1.5 + 0.8),
			label_font_size)
		i += 1

	# decals row underneath
	var decals: Array = []
	var ddir := DirAccess.open(decals_dir)
	if ddir:
		ddir.list_dir_begin()
	var fname := ddir.get_next()
	while fname != "":
		if fname.ends_with(".png"):
			var tex := _load_texture(decals_dir.path_join(fname))
			if tex != null:
				decals.append({"name": fname.get_basename(), "tex": tex})
		fname = ddir.get_next()
	decals.sort_custom(func(a, b): return String(a.name) < String(b.name))

	var rows_used := (entries.size() + columns - 1) / columns
	var dcol := 0
	var drow := rows_used + 2
	for entry in decals:
		var sprite := Sprite2D.new()
		sprite.texture = entry.tex
		sprite.scale = Vector2.ONE * (cell_m / 512.0)
		var col := dcol % columns
		if col == 0 and dcol > 0:
			drow += 1
		sprite.position = _cell_pos(col, drow, cell_m) + Vector2(0, 100)
		add_child(sprite)
		_label(String(entry.name), sprite.position + Vector2(0, cell_m * 0.5 + 0.6), 18)
		dcol += 1


func _cell_pos(col: int, row: int, size_m: float) -> Vector2:
	return Vector2(
		(col - (columns - 1) * 0.5) * (size_m * 3.0 + 2.0),
		row * (size_m * 3.0 + 4.0) + 20.0)


func _label(text: String, pos: Vector2, font_size: int) -> void:
	var l := Label.new()
	l.text = text
	l.position = pos
	l.add_theme_font_size_override("font_size", font_size)
	l.add_theme_color_override("font_color", Color(0.92, 0.91, 0.87))
	l.add_theme_color_override("font_outline_color", Color(0.05, 0.05, 0.05))
	l.add_theme_constant_override("outline_size", 6)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	add_child(l)
