# -*- coding: utf-8 -*-
"""Download OSM data for the Pripyat / Chernobyl NPP area via Overpass API.

Output: data/raw/pripyat_zone_overpass.json
"""
import json
import os
import sys
import time

import requests

# Bounding box: Pripyat city + ChNPP + cooling pond + Yaniv
BBOX = {
    "south": 51.380,
    "west": 30.010,
    "north": 51.435,
    "east": 30.130,
}

OVERPASS_ENDPOINTS = [
    "https://overpass-api.de/api/interpreter",
    "https://overpass.kumi.systems/api/interpreter",
    "https://maps.mail.ru/osm/tools/overpass/api/interpreter",
]

QUERY = """
[out:json][timeout:180];
(
  way["building"]({s},{w},{n},{e});
  relation["building"]({s},{w},{n},{e});
  way["building:part"]({s},{w},{n},{e});
  way["highway"]({s},{w},{n},{e});
  way["railway"]({s},{w},{n},{e});
  way["barrier"]({s},{w},{n},{e});
  way["waterway"]({s},{w},{n},{e});
  way["natural"~"water|wetland|wood|scrub|sand|heath"]({s},{w},{n},{e});
  relation["natural"~"water|wood"]({s},{w},{n},{e});
  way["landuse"~"forest|grass|farmland|meadow|industrial|residential|quarry|landfill|cemetery|military|orchard|allotments"]({s},{w},{n},{e});
  relation["landuse"~"forest|farmland"]({s},{w},{n},{e});
  way["leisure"~"park|stadium|pitch"]({s},{w},{n},{e});
  way["power"~"line|minor_line"]({s},{w},{n},{e});
  node["power"~"tower|pole|station"]({s},{w},{n},{e});
  way["man_made"~"chimney|cooling_tower|crane|mast|tower|works|storage_tank|pond|embankment|pier|breakwater"]({s},{w},{n},{e});
  way["aeroway"]({s},{w},{n},{e});
);
(._;>;);
out body;
""".format(s=BBOX["south"], w=BBOX["west"], n=BBOX["north"], e=BBOX["east"])

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT_DIR = os.path.join(ROOT, "data", "raw")
os.makedirs(OUT_DIR, exist_ok=True)
OUT_PATH = os.path.join(OUT_DIR, "pripyat_zone_overpass.json")


def main():
    last_err = None
    for endpoint in OVERPASS_ENDPOINTS:
        try:
            print(f"Trying {endpoint} ...")
            resp = requests.post(
                endpoint,
                data={"data": QUERY},
                headers={"User-Agent": "pripyat-godot-map/1.0 (game dev research)"},
                timeout=300,
            )
            resp.raise_for_status()
            data = resp.json()
            elements = data.get("elements", [])
            if not elements:
                raise RuntimeError("empty response")
            with open(OUT_PATH, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False)
            counts = {}
            for el in elements:
                counts[el["type"]] = counts.get(el["type"], 0) + 1
            print(f"OK: {len(elements)} elements -> {OUT_PATH}")
            print("   ", counts)
            return 0
        except Exception as exc:  # noqa: BLE001
            last_err = exc
            print(f"   failed: {exc}")
            time.sleep(2)
    print(f"All endpoints failed. Last error: {last_err}", file=sys.stderr)
    return 1


if __name__ == "__main__":
    sys.exit(main())
