# -*- coding: utf-8 -*-
"""Render the processed game JSON into a top-down map PNG.

Output:
  textures/pripyat_zone_map.png   (4096 px wide, labelled)
  textures/pripyat_zone_preview.png (1400 px wide, for quick look)
"""
import json
import math
import os

from PIL import Image, ImageDraw, ImageFont

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
GAME_PATH = os.path.join(ROOT, "godot", "data", "pripyat_zone_game.json")
OUT_DIR = os.path.join(ROOT, "textures")
OUT_MAIN = os.path.join(OUT_DIR, "pripyat_zone_map.png")
OUT_CLEAN = os.path.join(OUT_DIR, "pripyat_zone_clean.png")
OUT_PREVIEW = os.path.join(OUT_DIR, "pripyat_zone_preview.png")

WIDTH_PX = 4096
SSAA = 2  # supersampling factor
BG = (232, 228, 214)          # paper
GRID = (210, 205, 190)

COLORS = {
    "forest": (108, 139, 88),
    "scrub": (140, 158, 110),
    "water": (126, 165, 200),
    "residential": (222, 216, 200),
    "industrial": (214, 208, 196),
    "quarry": (222, 213, 190),
    "farmland": (226, 219, 186),
    "grass": (218, 216, 190),
    "meadow": (220, 217, 186),
    "cemetery": (214, 212, 196),
    "military": (219, 213, 198),
    "landfill": (216, 210, 194),
    "building": (72, 68, 62),
    "building_outline": (48, 45, 41),
    "building_part": (96, 92, 86),
}

ROAD_COLORS = {
    "motorway": (214, 120, 70), "trunk": (214, 120, 70),
    "primary": (206, 140, 92), "secondary": (196, 160, 120),
    "tertiary": (180, 168, 150), "residential": (178, 172, 160),
    "unclassified": (178, 172, 160), "living_street": (182, 176, 164),
    "service": (186, 180, 168), "track": (170, 160, 140),
    "pedestrian": (196, 190, 178), "footway": (190, 184, 172),
    "path": (190, 184, 172), "cycleway": (190, 184, 172), "steps": (190, 184, 172),
}

RAIL = (90, 86, 80)
WATERWAY = (100, 145, 190)
BARRIER = (176, 116, 96)
POWER = (150, 146, 140)

FONT_CANDIDATES = [
    "C:/Windows/Fonts/segoeuisemibold.ttf",
    "C:/Windows/Fonts/arial.ttf",
    "C:/Windows/Fonts/segoeui.ttf",
]


def load_font(size):
    for p in FONT_CANDIDATES:
        if os.path.exists(p):
            try:
                return ImageFont.truetype(p, size)
            except OSError:
                continue
    return ImageFont.load_default()


def main():
    with open(GAME_PATH, encoding="utf-8") as f:
        game = json.load(f)
    os.makedirs(OUT_DIR, exist_ok=True)
    render(game, decorated=True, out_path=OUT_MAIN)
    render(game, decorated=True, out_path=OUT_PREVIEW, thumbnail=1400)
    render(game, decorated=False, out_path=OUT_CLEAN)


def render(game, decorated=True, out_path=OUT_MAIN, thumbnail=None):
    layers = game["layers"]
    ext_w, ext_h = game["meta"]["extent_m"]

    scale = WIDTH_PX / ext_w  # px per metre (final)
    W = WIDTH_PX
    H = int(round(ext_h * scale))
    pad = 48 if decorated else 0

    # supersampled canvas
    SW, SH = (W + pad * 2) * SSAA, (H + pad * 2) * SSAA
    img = Image.new("RGB", (SW, SH), BG)
    d = ImageDraw.Draw(img)

    def to_px(x, y):
        return ((x + ext_w / 2) * scale + pad) * SSAA, ((y + ext_h / 2) * scale + pad) * SSAA

    def px_len(m):
        return m * scale * SSAA

    # ---- landuse underlay ----
    for poly in layers["landuse"]["polygons"]:
        kind = poly["props"].get("kind") or ""
        col = COLORS.get(kind, COLORS["residential"])
        d.polygon([to_px(x, y) for x, y in poly["outer"]], fill=col)
        for hole in poly["holes"]:
            d.polygon([to_px(x, y) for x, y in hole], fill=BG)

    # ---- forest ----
    for poly in layers["forest"]["polygons"]:
        col = COLORS["forest"] if poly["props"].get("kind") == "wood" else COLORS["scrub"]
        d.polygon([to_px(x, y) for x, y in poly["outer"]], fill=col)
        for hole in poly["holes"]:
            d.polygon([to_px(x, y) for x, y in hole], fill=BG)

    # ---- grid (1 km) ----
    step = 1000.0
    x = -ext_w / 2
    while x <= ext_w / 2:
        d.line([to_px(x, -ext_h / 2), to_px(x, ext_h / 2)], fill=GRID, width=SSAA)
        x += step
    y = -ext_h / 2
    while y <= ext_h / 2:
        d.line([to_px(-ext_w / 2, y), to_px(ext_w / 2, y)], fill=GRID, width=SSAA)
        y += step

    # ---- water ----
    for poly in layers["water"]["polygons"]:
        d.polygon([to_px(x, y) for x, y in poly["outer"]], fill=COLORS["water"])
    for line in layers["waterways"]["lines"]:
        w = max(px_len(line["props"].get("width") or 6), 2 * SSAA)
        d.line([to_px(x, y) for x, y in line["points"]], fill=WATERWAY, width=int(w), joint="curve")

    # ---- railways ----
    for line in layers["railways"]["lines"]:
        pts = [to_px(x, y) for x, y in line["points"]]
        d.line(pts, fill=RAIL, width=int(px_len(3)), joint="curve")

    # ---- roads (major -> minor) ----
    for line in layers["roads"]["lines"]:
        kind = line["props"].get("kind", "service")
        col = ROAD_COLORS.get(kind, ROAD_COLORS["service"])
        w = max(px_len(line["props"].get("width") or 4), 1.6 * SSAA)
        d.line([to_px(x, y) for x, y in line["points"]], fill=col, width=int(w), joint="curve")

    # ---- barriers (fences / walls) ----
    for line in layers["barriers"]["lines"]:
        pts = [to_px(x, y) for x, y in line["points"]]
        d.line(pts, fill=BARRIER, width=max(int(px_len(0.6)), SSAA), joint="curve")

    # ---- power lines ----
    for line in layers["powerlines"]["lines"]:
        pts = [to_px(x, y) for x, y in line["points"]]
        d.line(pts, fill=POWER, width=max(int(px_len(0.5)), SSAA))

    # ---- buildings ----
    bo = max(int(px_len(0.5)), SSAA)
    for poly in layers["building_parts"]["polygons"]:
        d.polygon([to_px(x, y) for x, y in poly["outer"]], fill=COLORS["building_part"], outline=COLORS["building_outline"], width=bo)
    for poly in layers["buildings"]["polygons"]:
        d.polygon([to_px(x, y) for x, y in poly["outer"]], fill=COLORS["building"], outline=COLORS["building_outline"], width=bo)
        for hole in poly["holes"]:
            d.polygon([to_px(x, y) for x, y in hole], fill=BG)

    # ---- labels ----
    font = load_font(int(26 * SSAA))
    small = load_font(int(20 * SSAA))
    named = []
    for poly in layers["buildings"]["polygons"]:
        if poly["props"].get("name"):
            ring = poly["outer"]
            area = abs(sum(ring[i][0] * ring[i + 1][1] - ring[i + 1][0] * ring[i][1] for i in range(len(ring) - 1))) / 2
            named.append((area, poly["props"]["name"], ring))
    named.sort(reverse=True)
    for area, name, ring in named[:60 if decorated else 0]:
        cx = sum(p[0] for p in ring) / len(ring)
        cy = sum(p[1] for p in ring) / len(ring)
        px, py = to_px(cx, cy)
        if area < 2500:
            continue
        d.ellipse([px - 4 * SSAA, py - 4 * SSAA, px + 4 * SSAA, py + 4 * SSAA], fill=(30, 28, 26))
        d.text((px, py), name, font=small if area < 15000 else font,
               fill=(28, 26, 24), anchor="mm",
               stroke_width=2 * SSAA, stroke_fill=(240, 238, 228))

    # ---- scale bar + attribution + north arrow (decorated version only) ----
    if decorated:
        bar_m = 1000
        x0, y0 = pad * SSAA + 10, (H + pad) * SSAA - 26 * SSAA
        d.rectangle([x0, y0, x0 + px_len(bar_m), y0 + 8 * SSAA], outline=(40, 38, 36), width=2 * SSAA)
        d.rectangle([x0, y0, x0 + px_len(bar_m) / 2, y0 + 8 * SSAA], fill=(40, 38, 36))
        d.text((x0, y0 - 4 * SSAA), "1 km", font=font, fill=(40, 38, 36), anchor="lb")
        d.text(((W + pad) * SSAA - 10, y0 + 10 * SSAA), "(c) OpenStreetMap contributors (ODbL)",
               font=small, fill=(90, 88, 84), anchor="rd")
        nx, ny = (W + pad) * SSAA - 60 * SSAA, (pad + 40) * SSAA
        d.polygon([(nx, ny - 30 * SSAA), (nx - 10 * SSAA, ny + 20 * SSAA), (nx, ny + 10 * SSAA), (nx + 10 * SSAA, ny + 20 * SSAA)], fill=(40, 38, 36))
        d.text((nx, ny + 34 * SSAA), "N", font=font, fill=(40, 38, 36), anchor="mm")
        d.text((pad * SSAA + 10, pad * SSAA + 6), "Pripyat / Chernobyl NPP zone",
               font=load_font(int(34 * SSAA)), fill=(40, 38, 36))

    # downscale (antialias) and save
    img = img.resize((W + pad * 2, H + pad * 2), Image.LANCZOS)
    img.save(out_path, optimize=True)
    print(f"saved: {out_path} {img.size}")
    if thumbnail:
        prev = img.copy()
        prev.thumbnail((thumbnail, thumbnail), Image.LANCZOS)
        prev.save(OUT_PREVIEW, optimize=True)
        print(f"preview: {OUT_PREVIEW} {prev.size}")


if __name__ == "__main__":
    main()
