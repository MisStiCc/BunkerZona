# -*- coding: utf-8 -*-
"""Fetch a real DEM heightmap for the bbox from the public AWS Terrain
(terrarium) tiles and write an 8-bit grayscale heightmap + range metadata.

Output:
  textures/pripyat_heightmap.png   (grayscale, 8-bit, aligned like the clean map)
  godot/data/heightmap_meta.json   (min/max elevation for decoding)
"""
import io
import json
import math
import os

import requests
from PIL import Image

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT_PNG = os.path.join(ROOT, "textures", "pripyat_heightmap.png")
OUT_META = os.path.join(ROOT, "godot", "data", "heightmap_meta.json")

BBOX = {"south": 51.380, "west": 30.010, "north": 51.435, "east": 30.130}
ZOOM = 13  # ~19 m/px at this latitude


def deg2tile(lat, lon, z):
    n = 2 ** z
    x = (lon + 180.0) / 360.0 * n
    lat_r = math.radians(lat)
    y = (1.0 - math.log(math.tan(lat_r) + 1 / math.cos(lat_r)) / math.pi) / 2.0 * n
    return x, y


def main():
    x_left, y_top = deg2tile(BBOX["north"], BBOX["west"], ZOOM)    # NW corner
    x_right, y_bottom = deg2tile(BBOX["south"], BBOX["east"], ZOOM)  # SE corner
    tx0, tx1 = int(x_left), int(x_right)
    ty0, ty1 = int(y_top), int(y_bottom)  # y grows southwards
    print(f"tiles x {tx0}..{tx1}, y {ty0}..{ty1} (z={ZOOM})")

    canvas = Image.new("RGB", ((tx1 - tx0 + 1) * 256, (ty1 - ty0 + 1) * 256))
    for tx in range(tx0, tx1 + 1):
        for ty in range(ty0, ty1 + 1):
            url = f"https://s3.amazonaws.com/elevation-tiles-prod/terrarium/{ZOOM}/{tx}/{ty}.png"
            r = requests.get(url, timeout=60)
            r.raise_for_status()
            tile = Image.open(io.BytesIO(r.content)).convert("RGB")
            canvas.paste(tile, ((tx - tx0) * 256, (ty - ty0) * 256))
            print("  got", url.rsplit('/', 1)[-1])

    # crop to exact bbox (fractional tiles)
    left = int((x_left - tx0) * 256)
    top = int((y_top - ty0) * 256)
    right = int((x_right - tx0) * 256)
    bottom = int((y_bottom - ty0) * 256)
    region = canvas.crop((left, top, right, bottom))

    # decode terrarium: elev = R*256 + G + B/256 - 32768
    px = region.load()
    w, h = region.size
    elev_min, elev_max = 1e9, -1e9
    elev = [[0.0] * w for _ in range(h)]
    for yy in range(h):
        for xx in range(w):
            r, g, b = px[xx, yy]
            e = r * 256 + g + b / 256.0 - 32768.0
            elev[yy][xx] = e
            elev_min = min(elev_min, e)
            elev_max = max(elev_max, e)

    span = max(elev_max - elev_min, 1e-6)
    hm = Image.new("L", (w, h))
    hpx = hm.load()
    for yy in range(h):
        for xx in range(w):
            hpx[xx, yy] = int(round((elev[yy][xx] - elev_min) / span * 255.0))
    os.makedirs(os.path.dirname(OUT_PNG), exist_ok=True)
    hm.save(OUT_PNG, optimize=True)
    print(f"heightmap: {OUT_PNG} {hm.size}, elev {elev_min:.1f}..{elev_max:.1f} m")

    meta = {
        "file": "res://../textures/pripyat_heightmap.png",
        "width_px": w,
        "height_px": h,
        "elev_min_m": round(elev_min, 2),
        "elev_max_m": round(elev_max, 2),
        "decode": "elev_m = elev_min_m + gray/255*(elev_max_m-elev_min_m)",
        "bbox": BBOX,
        "source": "Mapzen/AWS Terrain tiles (terrarium), SRTM & other open DEMs",
    }
    os.makedirs(os.path.dirname(OUT_META), exist_ok=True)
    with open(OUT_META, "w", encoding="utf-8") as f:
        json.dump(meta, f, indent=2)
    print(f"meta: {OUT_META}")


if __name__ == "__main__":
    main()
