# -*- coding: utf-8 -*-
"""Process raw Overpass JSON into:
  1. data/pripyat_zone.geojson          - standard WGS84 GeoJSON (QGIS/JOSM/etc.)
  2. godot/data/pripyat_zone_game.json  - game-ready local-metre coordinates

Coordinate system of the game file:
  +x -> east, +y -> south (Godot 2D friendly), origin at bbox centre, units = metres.
"""
import json
import math
import os
from datetime import date

from shapely.geometry import Polygon, LineString, MultiPolygon
from shapely.ops import unary_union

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RAW_PATH = os.path.join(ROOT, "data", "raw", "pripyat_zone_overpass.json")
GEOJSON_PATH = os.path.join(ROOT, "data", "pripyat_zone.geojson")
GODOT_DIR = os.path.join(ROOT, "godot", "data")
GAME_PATH = os.path.join(GODOT_DIR, "pripyat_zone_game.json")

BBOX = {"south": 51.380, "west": 30.010, "north": 51.435, "east": 30.130}
LAT0 = (BBOX["south"] + BBOX["north"]) / 2
LON0 = (BBOX["west"] + BBOX["east"]) / 2
M_PER_DEG_LAT = 110574.0
M_PER_DEG_LON = 111320.0 * math.cos(math.radians(LAT0))


def lonlat_to_local(lon, lat):
    """WGS84 -> local metres (x east, y south), origin at bbox centre."""
    x = (lon - LON0) * M_PER_DEG_LON
    y = (LAT0 - lat) * M_PER_DEG_LAT
    return [round(x, 1), round(y, 1)]


ROAD_WIDTHS = {
    "motorway": 16, "trunk": 14, "primary": 12, "secondary": 10,
    "tertiary": 8, "unclassified": 6, "residential": 6, "living_street": 5,
    "service": 4, "track": 3, "pedestrian": 4, "footway": 1.5, "path": 1.2,
    "cycleway": 1.5, "steps": 1.0,
}
ROAD_PRIORITY = {
    "motorway": 0, "trunk": 1, "primary": 2, "secondary": 3, "tertiary": 4,
    "unclassified": 5, "residential": 6, "living_street": 7, "service": 8,
    "track": 9, "pedestrian": 10, "footway": 11, "path": 12, "cycleway": 13,
    "steps": 14,
}


def parse_float(value):
    try:
        return round(float(value), 1)
    except (TypeError, ValueError):
        return None


def main():
    with open(RAW_PATH, encoding="utf-8") as f:
        data = json.load(f)

    nodes = {}
    ways = {}
    relations = {}
    for el in data["elements"]:
        if el["type"] == "node":
            nodes[el["id"]] = el
        elif el["type"] == "way":
            ways[el["id"]] = el
        elif el["type"] == "relation":
            relations[el["id"]] = el

    def way_local_coords(w):
        return [lonlat_to_local(nodes[n]["lon"], nodes[n]["lat"]) for n in w["nodes"] if n in nodes]

    def way_lonlat_coords(w):
        return [[nodes[n]["lon"], nodes[n]["lat"]] for n in w["nodes"] if n in nodes]

    def rings_from_members(rel, member_roles=("outer",)):
        """Assemble closed rings from relation member ways (multipolygon)."""
        segments = []
        for m in rel.get("members", []):
            if m["type"] == "way" and m.get("role") in member_roles and m["ref"] in ways:
                coords = way_local_coords(ways[m["ref"]])
                if len(coords) >= 2:
                    segments.append(coords)
        rings = []
        current = []
        remaining = list(segments)
        while remaining:
            if not current:
                current = list(remaining.pop(0))
            progressed = True
            while progressed and current[0] != current[-1]:
                progressed = False
                for i, seg in enumerate(remaining):
                    if not seg:
                        continue
                    if seg[0] == current[-1]:
                        current.extend(seg[1:])
                    elif seg[-1] == current[-1]:
                        current.extend(list(reversed(seg))[1:])
                    elif seg[-1] == current[0]:
                        current = seg[:-1] + current
                    elif seg[0] == current[0]:
                        current = list(reversed(seg))[:-1] + current
                    else:
                        continue
                    remaining.pop(i)
                    progressed = True
                    break
            if len(current) >= 4 and current[0] == current[-1]:
                rings.append(current)
            elif len(current) >= 4:
                rings.append(current + [current[0]])  # force-close small gaps
            current = []
        return rings

    def build_multipolygon(rel):
        outers = rings_from_members(rel, ("outer", ""))
        inners = rings_from_members(rel, ("inner",))
        if not outers:
            return None
        try:
            outer_polys = [Polygon(r) for r in outers]
            outer_union = unary_union([p for p in outer_polys if p.is_valid or p.buffer(0)])
            if inners:
                inner_union = unary_union([Polygon(r).buffer(0) for r in inners])
                result = outer_union.difference(inner_union)
            else:
                result = outer_union
            geoms = result.geoms if hasattr(result, "geoms") else [result]
            return [g for g in geoms if g.area > 1.0]
        except Exception:
            return [Polygon(r).buffer(0) for r in outers if Polygon(r).buffer(0).area > 1.0]

    def geom_to_json(geoms):
        out = []
        for g in geoms:
            out.append([[round(c, 1) for c in pt] for pt in g.exterior.coords])
        return out

    def clean_polygons_from_ring(ring):
        """Validate/repair a raw ring; returns a list of valid shapely polygons
        (buffer(0) fixes self-intersections, may split into several parts)."""
        try:
            p = Polygon(ring)
            if not p.is_valid:
                p = p.buffer(0)
            if p.is_empty:
                return []
            if hasattr(p, "geoms"):
                return [g for g in p.geoms if g.area > 5.0]
            return [p] if p.area > 5.0 else []
        except Exception:
            return []

    def add_cleaned_building(coords_local, tags, target):
        """Add building polygon(s) after geometric repair (collision-safe)."""
        n = 0
        for g in clean_polygons_from_ring(coords_local):
            ring_local = [[round(x, 1), round(y, 1)] for x, y in g.exterior.coords]
            if len(ring_local) < 4:
                continue
            holes_local = [[[round(x, 1), round(y, 1)] for x, y in i.coords] for i in g.interiors]
            props = {
                "name": tags.get("name"),
                "kind": tags.get("building") or tags.get("building:part") or "yes",
            }
            if tags.get("height"):
                props["height"] = parse_float(tags["height"])
            if tags.get("building:levels"):
                props["levels"] = parse_float(tags["building:levels"])
            target.append({"outer": ring_local, "holes": holes_local, "props": props})
            ring_ll = [
                [round(LON0 + x / M_PER_DEG_LON, 7), round(LAT0 - y / M_PER_DEG_LAT, 7)]
                for x, y in ring_local
            ]
            holes_ll = [
                [[round(LON0 + x / M_PER_DEG_LON, 7), round(LAT0 - y / M_PER_DEG_LAT, 7)] for x, y in h]
                for h in holes_local
            ]
            geojson_features.append({
                "type": "Feature",
                "geometry": {"type": "Polygon", "coordinates": [ring_ll] + holes_ll},
                "properties": dict(props),
            })
            n += 1
        return n

    # ---------------- collect features ----------------
    buildings = []       # polygons
    building_parts = []  # polygons (building:part)
    water = []           # polygons
    forest = []          # polygons
    landuse = []         # polygons (other)
    roads = []           # lines
    railways = []        # lines
    waterways = []       # lines
    barriers = []        # lines (fences, walls)
    powerlines = []      # lines
    pois = []            # points of interest
    geojson_features = []

    processed_relations = set()

    def add_polygon_feature(coords_ll, coords_local, tags, layer, geom_kind="polygon"):
        props = {
            "name": tags.get("name"),
            "kind": (tags.get("building") or tags.get("landuse") or tags.get("natural")
                     or tags.get("leisure") or tags.get("man_made") or geom_kind),
        }
        if tags.get("height"):
            props["height"] = parse_float(tags["height"])
        if tags.get("building:levels"):
            props["levels"] = parse_float(tags["building:levels"])
        entry = {"outer": coords_local, "holes": [], "props": props}
        layer.append(entry)
        geojson_features.append({
            "type": "Feature",
            "geometry": {"type": "Polygon", "coordinates": [coords_ll]},
            "properties": dict(props),
        })
        return entry

    # ---- relations (multipolygons) first ----
    for rid, rel in relations.items():
        tags = rel.get("tags", {})
        mp = build_multipolygon(rel)
        if not mp:
            continue
        processed_relations.add(rid)
        coords_ll_rings = None
        if tags.get("building"):
            target = buildings
        elif tags.get("natural") == "water":
            target = water
        elif tags.get("natural") in ("wood", "scrub") or tags.get("landuse") == "forest":
            target = forest
        else:
            target = landuse
        props = {
            "name": tags.get("name"),
            "kind": tags.get("building") or tags.get("natural") or tags.get("landuse") or "area",
        }
        for g in mp:
            ring_local = [[round(c, 1) for c in pt] for pt in g.exterior.coords]
            holes_local = [[[round(c, 1) for c in pt] for pt in i.coords] for i in g.interiors]
            target.append({"outer": ring_local, "holes": holes_local, "props": dict(props)})
            # lon/lat version for the GeoJSON (unproject)
            ring_ll = [
                [round(LON0 + x / M_PER_DEG_LON, 7), round(LAT0 - y / M_PER_DEG_LAT, 7)]
                for x, y in ring_local
            ]
            holes_ll = [
                [[round(LON0 + x / M_PER_DEG_LON, 7), round(LAT0 - y / M_PER_DEG_LAT, 7)] for x, y in h]
                for h in holes_local
            ]
            geojson_features.append({
                "type": "Feature",
                "geometry": {"type": "Polygon", "coordinates": [ring_ll] + holes_ll},
                "properties": dict(props),
            })

    # ---- ways ----
    for wid, w in ways.items():
        tags = w.get("tags", {})
        if not tags:
            continue
        coords_local = way_local_coords(w)
        coords_ll = way_lonlat_coords(w)
        closed = len(w["nodes"]) > 3 and w["nodes"][0] == w["nodes"][-1]

        def base_props():
            return {
                "name": tags.get("name"),
                "kind": None,
            }

        if tags.get("building"):
            if closed:
                add_cleaned_building(coords_local, tags, buildings)
            continue
        if tags.get("building:part"):
            if closed:
                add_cleaned_building(coords_local, tags, building_parts)
            continue
        if tags.get("highway"):
            hw = tags["highway"]
            props = base_props()
            props["kind"] = hw
            props["width"] = parse_float(tags.get("width")) or ROAD_WIDTHS.get(hw, 5)
            if tags.get("bridge") in ("yes", "true"):
                props["bridge"] = True
            roads.append({"points": coords_local, "props": props})
            geojson_features.append({
                "type": "Feature",
                "geometry": {"type": "LineString", "coordinates": coords_ll},
                "properties": dict(props),
            })
            continue
        if tags.get("railway"):
            props = base_props()
            props["kind"] = tags["railway"]
            railways.append({"points": coords_local, "props": props})
            geojson_features.append({
                "type": "Feature",
                "geometry": {"type": "LineString", "coordinates": coords_ll},
                "properties": {"name": props["name"], "kind": props["kind"]},
            })
            continue
        if tags.get("waterway"):
            props = base_props()
            props["kind"] = tags["waterway"]
            props["width"] = parse_float(tags.get("width")) or 6
            waterways.append({"points": coords_local, "props": props})
            geojson_features.append({
                "type": "Feature",
                "geometry": {"type": "LineString", "coordinates": coords_ll},
                "properties": dict(props),
            })
            continue
        if tags.get("power") in ("line", "minor_line"):
            powerlines.append({"points": coords_local, "props": {"kind": tags["power"]}})
            geojson_features.append({
                "type": "Feature",
                "geometry": {"type": "LineString", "coordinates": coords_ll},
                "properties": {"kind": tags["power"]},
            })
            continue
        if tags.get("barrier"):
            barriers.append({"points": coords_local, "props": {"kind": tags["barrier"]}})
            geojson_features.append({
                "type": "Feature",
                "geometry": {"type": "LineString", "coordinates": coords_ll},
                "properties": {"kind": tags["barrier"]},
            })
            continue
        if closed and (tags.get("natural") == "water" or tags.get("waterway") in ("riverbank", "dock")):
            add_polygon_feature(coords_ll, coords_local, tags, water, "water")
            continue
        if closed and (tags.get("natural") in ("wood", "scrub") or tags.get("landuse") == "forest"):
            add_polygon_feature(coords_ll, coords_local, tags, forest, "forest")
            continue
        if closed and (tags.get("landuse") or tags.get("natural") or tags.get("leisure") or tags.get("man_made")):
            add_polygon_feature(coords_ll, coords_local, tags, landuse)
            continue
        if closed and tags.get("aeroway"):
            add_polygon_feature(coords_ll, coords_local, tags, landuse)
            continue

    # ---- nodes: POIs ----
    POI_KEYS = ("tourism", "historic", "amenity", "leisure", "man_made", "military", "power")
    for nid, n in nodes.items():
        tags = n.get("tags", {})
        if not tags:
            continue
        if any(k in tags for k in POI_KEYS) and tags.get("name"):
            kind = next((tags[k] for k in POI_KEYS if k in tags), "poi")
            pos = lonlat_to_local(n["lon"], n["lat"])
            pois.append({"pos": pos, "name": tags["name"], "kind": kind})
            geojson_features.append({
                "type": "Feature",
                "geometry": {"type": "Point", "coordinates": [n["lon"], n["lat"]]},
                "properties": {"name": tags["name"], "kind": kind},
            })

    # roads sorted: major first (so footpaths draw on top)
    roads.sort(key=lambda r: ROAD_PRIORITY.get(r["props"]["kind"], 20))

    # POIs from named buildings (label anchors for the game / map render)
    for b in buildings:
        if b["props"].get("name"):
            ring = b["outer"]
            cx = sum(p[0] for p in ring) / len(ring)
            cy = sum(p[1] for p in ring) / len(ring)
            pois.append({"pos": [round(cx, 1), round(cy, 1)],
                         "name": b["props"]["name"], "kind": "building"})

    # ---------------- write GeoJSON ----------------
    os.makedirs(os.path.dirname(GEOJSON_PATH), exist_ok=True)
    geojson = {
        "type": "FeatureCollection",
        "name": "pripyat_zone",
        "crs": {"type": "name", "properties": {"name": "urn:ogc:def:crs:OGC:1.3:CRS84"}},
        "attribution": "(c) OpenStreetMap contributors, ODbL 1.0",
        "features": geojson_features,
    }
    with open(GEOJSON_PATH, "w", encoding="utf-8") as f:
        json.dump(geojson, f, ensure_ascii=False)

    # ---------------- write game JSON ----------------
    os.makedirs(GODOT_DIR, exist_ok=True)
    game = {
        "meta": {
            "title": "Pripyat / Chernobyl NPP zone",
            "source": "OpenStreetMap",
            "license": "ODbL 1.0, (c) OpenStreetMap contributors",
            "generated": str(date.today()),
            "bbox": BBOX,
            "origin_lat": LAT0,
            "origin_lon": LON0,
            "units": "metres",
            "axes": "+x east, +y south (Godot 2D screen space)",
            "extent_m": [
                round((BBOX["east"] - BBOX["west"]) * M_PER_DEG_LON),
                round((BBOX["north"] - BBOX["south"]) * M_PER_DEG_LAT),
            ],
        },
        "layers": {
            "buildings": {"polygons": buildings},
            "building_parts": {"polygons": building_parts},
            "water": {"polygons": water},
            "forest": {"polygons": forest},
            "landuse": {"polygons": landuse},
            "roads": {"lines": roads},
            "railways": {"lines": railways},
            "waterways": {"lines": waterways},
            "barriers": {"lines": barriers},
            "powerlines": {"lines": powerlines},
            "pois": {"points": pois},
        },
    }
    with open(GAME_PATH, "w", encoding="utf-8") as f:
        json.dump(game, f, ensure_ascii=False)

    # ---------------- stats ----------------
    def total_len(lines):
        t = 0.0
        for ln in lines:
            pts = ln["points"]
            t += sum(math.dist(pts[i], pts[i + 1]) for i in range(len(pts) - 1))
        return t

    stats = {
        "buildings": len(buildings),
        "building_parts": len(building_parts),
        "water_polygons": len(water),
        "forest_polygons": len(forest),
        "landuse_polygons": len(landuse),
        "roads": len(roads),
        "roads_km": round(total_len(roads) / 1000, 1),
        "railways": len(railways),
        "railways_km": round(total_len(railways) / 1000, 1),
        "waterways": len(waterways),
        "barriers": len(barriers),
        "powerlines": len(powerlines),
        "pois": len(pois),
    }
    print(json.dumps(stats, indent=2, ensure_ascii=False))
    named = [b for b in buildings if b["props"].get("name")]
    print(f"\nNamed buildings: {len(named)}")
    for b in named[:15]:
        print("  -", b["props"]["name"], f"(h={b['props'].get('height')}, lvl={b['props'].get('levels')})")
    print(f"\nPOIs sample:")
    for p in pois[:20]:
        print("  *", p["name"], f"[{p['kind']}]")


if __name__ == "__main__":
    main()
