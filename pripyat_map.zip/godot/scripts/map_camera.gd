extends Camera2D
## Free camera for browsing the map: WASD / arrows to pan, mouse wheel to zoom
## (towards the cursor), Q/E or middle-drag to pan as well.
## Shows building name labels ("map_labels" group) above a zoom threshold.

@export var pan_speed_m_per_s: float = 600.0
@export var zoom_step: float = 1.2
@export var min_zoom: float = 0.015   # whole-zone view
@export var max_zoom: float = 4.0     # close-up (1 world metre = 4 px)
@export var labels_min_zoom: float = 0.35

var _drag_active := false


func _ready() -> void:
	zoom = Vector2(0.25, 0.25)
	position = Vector2.ZERO
	make_current()


func _process(delta: float) -> void:
	var dir := Input.get_vector("ui_left", "ui_right", "ui_up", "ui_down")
	if Input.is_key_pressed(KEY_A):
		dir.x -= 1.0
	if Input.is_key_pressed(KEY_D):
		dir.x += 1.0
	if Input.is_key_pressed(KEY_W):
		dir.y -= 1.0
	if Input.is_key_pressed(KEY_S):
		dir.y += 1.0
	position += dir.normalized() / zoom * pan_speed_m_per_s * delta
	_update_labels()


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseButton:
		var mb := event as InputEventMouseButton
		if mb.button_index == MOUSE_BUTTON_WHEEL_UP and mb.pressed:
			_zoom_by(1.0 / zoom_step, mb.position)
		elif mb.button_index == MOUSE_BUTTON_WHEEL_DOWN and mb.pressed:
			_zoom_by(zoom_step, mb.position)
		elif mb.button_index == MOUSE_BUTTON_MIDDLE:
			_drag_active = mb.pressed
	elif event is InputEventMouseMotion and _drag_active:
		var mm := event as InputEventMouseMotion
		position -= mm.relative / zoom
		_update_labels()


func _zoom_by(factor: float, anchor_screen: Vector2) -> void:
	var before := get_global_mouse_position()
	var target_zoom: float = clampf(zoom.x * factor, min_zoom, max_zoom)
	zoom = Vector2(target_zoom, target_zoom)
	# keep the point under the cursor anchored while zooming
	var after := get_global_mouse_position()
	position += before - after
	_update_labels()


func _update_labels() -> void:
	var show_labels := zoom.x >= labels_min_zoom
	var root := get_parent()
	if root and root.has_method("set_labels_visible"):
		root.set_labels_visible(show_labels)
