@tool
extends Node2D
## Scatters grunge decals (cracks / stains / moss / holes...) over the map
## to sell the abandoned-zone mood. Decals are plain Sprite2D nodes in the
## "grime" group; re-run by calling spawn(true).

@export_range(0, 5000, 50) var decal_count: int = 420
@export var decals_dir: String = "res://textures/decals"
@export var min_size_m: float = 8.0
@export var max_size_m: float = 42.0
@export var max_alpha: float = 0.8
@export var rng_seed: int = 20260426
@export var spawn_on_roads_only: bool = false
## Fallback extent if the map JSON is not reachable (metres, x/y half-widths).
@export var extent_fallback: Vector2 = Vector2(4166, 3041)

@onready var _container: Node2D = get_parent()


func _ready() -> void:
	# deferred: the map root is still setting up its children in _ready()
	spawn.call_deferred()


## Works both with imported resources and raw files (fresh checkout, no import).
static func _load_texture(path: String) -> Texture2D:
	if ResourceLoader.exists(path) and FileAccess.file_exists(path + ".import"):
		var t: Texture2D = load(path)
		if t != null:
			return t
	if FileAccess.file_exists(path):
		var img := Image.load_from_file(path)
		if img != null:
			return ImageTexture.create_from_image(img)
	return null


func spawn(force: bool = false) -> void:
	var old := get_node_or_null("Grime")
	if old:
		old.queue_free()
	var textures: Array[Texture2D] = []
	var dir := DirAccess.open(decals_dir)
	if dir:
		dir.list_dir_begin()
	var fname := dir.get_next()
	while fname != "":
		if fname.ends_with(".png"):
			var tex := _load_texture(decals_dir.path_join(fname))
			if tex != null:
				textures.append(tex)
		fname = dir.get_next()
	if textures.is_empty():
		push_warning("GrimeSpawner: no decals found in %s" % decals_dir)
		return

	var half_extent := extent_fallback
	var map := get_parent()
	if map and map.get("json_path"):
		var raw := FileAccess.get_file_as_string(map.json_path)
		var data: Dictionary = JSON.parse_string(raw)
		if data and data.has("meta") and data["meta"].has("extent_m"):
			var e: Array = data["meta"]["extent_m"]
			half_extent = Vector2(float(e[0]) * 0.5, float(e[1]) * 0.5)

	var rng := RandomNumberGenerator.new()
	rng.seed = rng_seed

	var holder := Node2D.new()
	holder.name = "Grime"
	holder.add_to_group("grime")
	_container.add_child(holder)

	for i in decal_count:
		var tex: Texture2D = textures[rng.randi_range(0, textures.size() - 1)]
		var s := Sprite2D.new()
		s.texture = tex
		var size_m := rng.randf_range(min_size_m, max_size_m)
		s.scale = Vector2.ONE * (size_m / 512.0)  # decals are authored at 512 px
		s.position = Vector2(
			rng.randf_range(-half_extent.x, half_extent.x),
			rng.randf_range(-half_extent.y, half_extent.y))
		s.rotation = rng.randf() * TAU
		s.modulate = Color(1, 1, 1, rng.randf_range(0.35, max_alpha))
		holder.add_child(s)
