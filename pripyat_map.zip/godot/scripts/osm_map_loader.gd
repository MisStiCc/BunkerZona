@tool
extends Node2D
## Builds the Pripyat / Chernobyl NPP map at runtime from the processed
## OpenStreetMap JSON (see ../tools/process_osm.py).
##
## World space: metres, origin at the centre of the exported bbox,
## +x = east, +y = south (matches Godot 2D screen space, north is -y).
##
## Layers created as children (also added to groups for easy access):
##   Underlay, Landuse, Forest, Water, Waterways, Railways, Roads,
##   Barriers, Powerlines, Buildings, Collision, Labels, POIs

@export_file("*.json") var json_path: String = "res://data/pripyat_zone_game.json"
## Add StaticBody2D + CollisionPolygon2D for every building (top-down gameplay).
@export var build_collision: bool = true
## Add name labels for notable buildings (group "map_labels").
@export var build_labels: bool = true
## Draw the pre-rendered clean texture under the vector data.
@export var draw_underlay_texture: bool = false
## Fallback height used when a building has no height/levels in OSM (metres).
@export var default_building_height_m: float = 15.0
## Min footprint area (m^2) for a building to get a label.
@export var label_min_area_m2: float = 2500.0

const LANDUSE_COLORS := {
	"residential": Color("ded8c8"),
	"industrial": Color("d6d0c4"),
	"farmland": Color("e2dbba"),
	"grass": Color("dad2be"),
	"meadow": Color("dcd9ba"),
	"quarry": Color("ded5be"),
	"cemetery": Color("d6d4c4"),
	"military": Color("dbd5c6"),
	"landfill": Color("d8d2c2"),
	"orchard": Color("d4d8b4"),
	"allotments": Color("dcd9ba"),
}
const LANDUSE_DEFAULT := Color("ddd8ca")
const FOREST_COLOR := Color("6c8b58")
const SCRUB_COLOR := Color("8c9e6e")
const WATER_COLOR := Color("7ea5c8")
const WATERWAY_COLOR := Color("6491be")
const BUILDING_COLOR := Color("48443e")
const BUILDING_PART_COLOR := Color("605c56")
const BARRIER_COLOR := Color("b07460")
const POWER_COLOR := Color("96928c")
const RAIL_COLOR := Color("5a5650")
const RAIL_INNER := Color("c8c4bc")
const ROAD_COLORS := {
	"motorway": Color("d67846"),
	"trunk": Color("d67846"),
	"primary": Color("ce8c5c"),
	"secondary": Color("c4a078"),
	"tertiary": Color("b4a896"),
	"residential": Color("b2ac9a"),
	"unclassified": Color("b2ac9a"),
	"living_street": Color("b6b0a4"),
	"service": Color("bab4a8"),
	"track": Color("aaa08c"),
	"pedestrian": Color("c4beb2"),
	"footway": Color("beb8ac"),
	"path": Color("beb8ac"),
	"cycleway": Color("beb8ac"),
	"steps": Color("beb8ac"),
}
const ROAD_DEFAULT := Color("bab4a8")
const UNDERLAY_PATH := "res://textures/pripyat_zone_clean.png"

var _layers: Dictionary = {}
var stats: Dictionary = {}


func _ready() -> void:
	_build()


func _build() -> void:
	for child in get_children():
		if child.owner == null or child.name in _layers.values():
			remove_child(child)
			child.queue_free()
	_layers.clear()

	if not FileAccess.file_exists(json_path):
		push_error("OSM map loader: file not found: %s" % json_path)
		return

	var raw := FileAccess.get_file_as_string(json_path)
	var data: Dictionary = JSON.parse_string(raw)
	if data == null or not data.has("layers"):
		push_error("OSM map loader: bad JSON in %s" % json_path)
		return
	var layers: Dictionary = data["layers"]
	var meta: Dictionary = data.get("meta", {})

	if draw_underlay_texture:
		_add_underlay(meta)

	# --- area layers, painting order: landuse -> forest -> water ---
	_fill_polygons("Landuse", layers.get("landuse", {}).get("polygons", []),
		func(kind: String) -> Color: return LANDUSE_COLORS.get(kind, LANDUSE_DEFAULT))
	_fill_polygons("Forest", layers.get("forest", {}).get("polygons", []),
		func(kind: String) -> Color:
			return FOREST_COLOR if kind == "wood" else SCRUB_COLOR)
	_fill_polygons("Water", layers.get("water", {}).get("polygons", []),
		func(_kind: String) -> Color: return WATER_COLOR)

	# --- line layers ---
	for line in layers.get("waterways", {}).get("lines", []):
		var w: float = float(line.get("props", {}).get("width", 6.0))
		_add_ribbon("Waterways", line["points"], maxf(w, 3.0), WATERWAY_COLOR)
	for line in layers.get("railways", {}).get("lines", []):
		var pts: Array = line["points"]
		_add_ribbon("Railways", pts, 4.0, RAIL_COLOR)
		_add_ribbon("Railways", pts, 1.4, RAIL_INNER)
	for line in layers.get("roads", {}).get("lines", []):
		var props: Dictionary = line.get("props", {})
		var kind: String = props.get("kind", "service")
		var w: float = float(props.get("width", 4.0))
		_add_ribbon("Roads", line["points"], maxf(w, 1.0), ROAD_COLORS.get(kind, ROAD_DEFAULT))
	for line in layers.get("barriers", {}).get("lines", []):
		_add_ribbon("Barriers", line["points"], 0.7, BARRIER_COLOR)
	for line in layers.get("powerlines", {}).get("lines", []):
		_add_ribbon("Powerlines", line["points"], 0.5, POWER_COLOR)

	# --- buildings (+ optional collision) ---
	var body: StaticBody2D
	if build_collision:
		body = StaticBody2D.new()
		body.name = "Collision"
		add_child(body)
		body.owner = owner
		_layers["Collision"] = body

	var buildings: Array = layers.get("buildings", {}).get("polygons", [])
	for poly in buildings:
		var outer := _to_vec2_array(poly["outer"])
		var p := Polygon2D.new()
		p.polygon = outer
		p.color = BUILDING_COLOR
		_get_layer("Buildings").add_child(p)
		if build_collision and body != null:
			var col := CollisionPolygon2D.new()
			col.polygon = outer
			col.build_mode = CollisionPolygon2D.BUILD_SOLIDS
			body.add_child(col)
	stats.buildings = buildings.size()

	for poly in layers.get("building_parts", {}).get("polygons", []):
		var p := Polygon2D.new()
		p.polygon = _to_vec2_array(poly["outer"])
		p.color = BUILDING_PART_COLOR
		_get_layer("BuildingParts").add_child(p)

	# --- labels + POIs ---
	if build_labels:
		_add_labels(buildings)
		_add_pois(layers.get("pois", {}).get("points", []))

	print("OSM map loader: %d buildings | extent %s m | origin lat/lon %s" % [
		buildings.size(),
		str(meta.get("extent_m", "?")),
		str(Vector2(float(meta.get("origin_lat", 0)), float(meta.get("origin_lon", 0)))),
	])


# ---------------------------------------------------------------- helpers ---

func _get_layer(layer_name: String) -> Node2D:
	if _layers.has(layer_name):
		return _layers[layer_name]
	var node := Node2D.new()
	node.name = layer_name
	node.add_to_group("map_layer")
	add_child(node)
	node.owner = owner
	_layers[layer_name] = node
	return node


func _fill_polygons(layer_name: String, polygons: Array, color_of: Callable) -> void:
	var parent := _get_layer(layer_name)
	for poly in polygons:
		var kind := String(poly.get("props", {}).get("kind", ""))
		var p := Polygon2D.new()
		p.polygon = _to_vec2_array(poly["outer"])
		p.color = color_of.call(kind)
		parent.add_child(p)


func _add_ribbon(layer_name: String, points: Array, width_m: float, color: Color) -> void:
	var ribbon := _ribbon_polygon(points, width_m)
	if ribbon.size() < 3:
		return
	var p := Polygon2D.new()
	p.polygon = ribbon
	p.color = color
	_get_layer(layer_name).add_child(p)


## Expand a polyline into a closed polygon of the given width (metres).
static func _ribbon_polygon(points: Array, width_m: float) -> PackedVector2Array:
	var pts: Array[Vector2] = []
	for raw in points:
		var v := Vector2(float(raw[0]), float(raw[1]))
		if pts.is_empty() or v.distance_to(pts[pts.size() - 1]) > 0.05:
			pts.append(v)
	if pts.size() < 2:
		return PackedVector2Array()
	var left: Array[Vector2] = []
	var right: Array[Vector2] = []
	var half := width_m * 0.5
	for i in pts.size():
		var dir := Vector2.ZERO
		if i == 0:
			dir = pts[1] - pts[0]
		elif i == pts.size() - 1:
			dir = pts[i] - pts[i - 1]
		else:
			dir = pts[i + 1] - pts[i - 1]
		dir = dir.normalized()
		var n := Vector2(-dir.y, dir.x) * half
		left.append(pts[i] + n)
		right.append(pts[i] - n)
	var poly: Array[Vector2] = left
	var right_rev: Array[Vector2] = right.duplicate()
	right_rev.reverse()
	poly.append_array(right_rev)
	return PackedVector2Array(poly)


static func _to_vec2_array(raw_points: Array) -> PackedVector2Array:
	var arr := PackedVector2Array()
	arr.resize(raw_points.size())
	for i in raw_points.size():
		arr[i] = Vector2(float(raw_points[i][0]), float(raw_points[i][1]))
	return arr


static func _ring_area(ring: Array) -> float:
	var a := 0.0
	for i in ring.size() - 1:
		a += float(ring[i][0]) * float(ring[i + 1][1]) - float(ring[i + 1][0]) * float(ring[i][1])
	return absf(a) * 0.5


static func _ring_centroid(ring: Array) -> Vector2:
	var cx := 0.0
	var cy := 0.0
	for p in ring:
		cx += float(p[0])
		cy += float(p[1])
	var n := float(ring.size())
	return Vector2(cx / n, cy / n)


func _add_labels(buildings: Array) -> void:
	var parent := _get_layer("Labels")
	var sorted: Array = []
	for poly in buildings:
		if poly.get("props", {}).get("name"):
			sorted.append(poly)
	sorted.sort_custom(func(a, b): return _ring_area(a["outer"]) > _ring_area(b["outer"]))
	var count := 0
	for poly in sorted:
		if count >= 60:
			break
		if _ring_area(poly["outer"]) < label_min_area_m2:
			continue
		var pos := _ring_centroid(poly["outer"])
		var label := Label.new()
		label.text = String(poly["props"]["name"])
		label.position = pos
		label.rotation = 0.0
		label.add_theme_font_size_override("font_size", 22)
		label.add_theme_color_override("font_color", Color("2a2724"))
		label.add_theme_color_override("font_outline_color", Color("f0eee4"))
		label.add_theme_constant_override("outline_size", 6)
		label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		label.size = Vector2.ZERO
		label.pivot_offset = Vector2(200, 0)  # rough centring for default width
		label.position -= Vector2(200, 11)
		label.add_to_group("map_labels")
		parent.add_child(label)
		count += 1


func _add_pois(points: Array) -> void:
	var parent := _get_layer("POIs")
	for poi in points:
		var pos := Vector2(float(poi["pos"][0]), float(poi["pos"][1]))
		var dot := Polygon2D.new()
		dot.polygon = PackedVector2Array([
			Vector2(-4, -4), Vector2(4, -4), Vector2(4, 4), Vector2(-4, 4)])
		dot.color = Color("1e1c1a")
		dot.position = pos
		dot.add_to_group("map_pois")
		parent.add_child(dot)


func _add_underlay(meta: Dictionary) -> void:
	if not ResourceLoader.exists(UNDERLAY_PATH):
		push_warning("Underlay texture not found: %s" % UNDERLAY_PATH)
		return
	var tex: Texture2D = load(UNDERLAY_PATH)
	var sprite := Sprite2D.new()
	sprite.name = "Underlay"
	var extent: Array = meta.get("extent_m", [0, 0])
	sprite.scale = Vector2(
		float(extent[0]) / float(tex.get_width()),
		float(extent[1]) / float(tex.get_height()))
	sprite.texture = tex
	sprite.z_index = -10
	sprite.modulate = Color(1, 1, 1, 1.0)
	_get_layer("Underlay").add_child(sprite)


## Toggle label visibility (also driven by map_camera.gd zoom level).
func set_labels_visible(visible_: bool) -> void:
	for node in get_tree().get_nodes_in_group("map_labels"):
		node.visible = visible_


## Convert a world position (metres) back to WGS84 lat/lon. Handy for
## debugging and for placing gameplay triggers from real coordinates.
func world_to_latlon(world_pos: Vector2) -> Vector2:
	var meta: Dictionary = _load_meta()
	var lat0 := float(meta.get("origin_lat", 0.0))
	var lon0 := float(meta.get("origin_lon", 0.0))
	var lat := lat0 - world_pos.y / 110574.0
	var lon := lon0 + world_pos.x / (111320.0 * cos(deg_to_rad(lat0)))
	return Vector2(lat, lon)


func latlon_to_world(latlon: Vector2) -> Vector2:
	var meta: Dictionary = _load_meta()
	var lat0 := float(meta.get("origin_lat", 0.0))
	var lon0 := float(meta.get("origin_lon", 0.0))
	var x := (latlon.y - lon0) * 111320.0 * cos(deg_to_rad(lat0))
	var y := (lat0 - latlon.x) * 110574.0
	return Vector2(x, y)


var _meta_cache: Dictionary


func _load_meta() -> Dictionary:
	if _meta_cache.is_empty():
		if FileAccess.file_exists(json_path):
			var data: Dictionary = JSON.parse_string(FileAccess.get_file_as_string(json_path))
			_meta_cache = data.get("meta", {})
	return _meta_cache
