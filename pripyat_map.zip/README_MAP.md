# Архив 1 — Карта зоны Припяти / ЧАЭС (Godot 4)

Реальная карта Припяти и Чернобыльской АЭС со строениями, дорогами, лесами,
водой и рельефом, подготовленная для игры на Godot 4.3+. Проект в папке
`godot/` самодостаточен и запускается сразу (F5).

## Состав архива

```
data/
  pripyat_zone.geojson           стандартный GeoJSON (WGS84) для QGIS и т.п.
  raw/pripyat_zone_overpass.json сырые данные Overpass API (архив)
textures/
  pripyat_zone_map.png           обзорная карта 4192×3086 с подписями
  pripyat_zone_clean.png         чистая подложка 4096×2990 (без рамок)
  pripyat_zone_preview.png       превью 1400 px
  pripyat_heightmap.png          карта высот 699×514 (~12 м/пкс, 8 бит)
godot/
  project.godot                  проект Godot 4.3+ (gl_compatibility)
  scenes/pripyat_map.tscn        главная сцена (карта + атмосфера + камера)
  scenes/atmosphere.tscn         пасмурность + пост-эффект на весь экран
  scripts/osm_map_loader.gd      построитель карты из JSON при запуске
  scripts/map_camera.gd          камера: WASD/стрелки, колесо, СКМ-drag
  scripts/grime_spawner.gd       рассыпание декалей грязи по карте
  shaders/grim_postfx.gdshader   десатурация/виньетка/зерно/мерцание
  data/pripyat_zone_game.json    игровые данные (метры, слои) — ядро карты
  data/heightmap_meta.json       min/max высоты для декодирования рельефа
  textures/pripyat_zone_clean.png, pripyat_heightmap.png
  textures/decals/               16 декалей для грязи (трещины, пятна, мох…)
tools/                           пайплайн регенерации (Python 3.11+)
  download_osm.py                скачать OSM (Overpass API), BBOX в начале
  process_osm.py                 -> GeoJSON + игровой JSON
  render_map.py                  -> PNG-карты
  fetch_heightmap.py             -> DEM heightmap (AWS Terrain Tiles)
```

## Данные карты

Охват: 51.380–51.435° с.ш., 30.010–30.130° в.д. — Припять, ЧАЭС (вкл. НБК),
пруд-охладитель, станция Янов, промзона, Красный лес (~8.3 × 6.1 км).

- 1186 зданий (229 с названиями: ДК «Энергетик», энергоблоки I–IV, машзал,
  автовокзал «Прип'ять», недостроенный Палац піонерів…)
- 240 building:part, 318 км дорог (все классы), 40 км ж/д, 68 линий
- 121 водный полигон, 134 лесных, 196 landuse, 150 заборов, 41 ЛЭП

Координаты игрового JSON: **метры**, origin в центре bbox (51.4075, 30.0700),
+X — восток, +Y — юг. Слои: buildings, building_parts, water, forest, landuse
(полигоны); roads, railways, waterways, barriers, powerlines (линии); pois.
API конвертации: `latlon_to_world()` / `world_to_latlon()` в лоадере.

## Запуск

1. Открыть папку `godot/` в Godot 4.3+ (проверено на 4.3 stable).
2. F5. Управление: WASD/стрелки — панорама, колесо — зум к курсору,
   СКМ+drag — перетаскивание. Подписи зданий — при зуме ≥ 0.35.
3. Настройки узла PripyatMap в инспекторе: `build_collision`
   (коллизия каждого здания — StaticBody2D+CollisionPolygon2D), `build_labels`,
   `draw_underlay_texture` (растровая подложка), `default_building_height_m`.
4. Демо-просмотр декалей и пост-эффекта уже включён в сцену.
   GrimeSpawner: плотность грязи (`decal_count`), размеры, альфа.

Экспорт билда: добавить `*.json` в фильтры включаемых файлов.

## Лицензия / атрибуция

- Картовые данные: © участники OpenStreetMap, ODbL 1.0 — при распространении
  игры обязательна атрибуция. Производная БД наследует ODbL (код игры — нет).
- Высоты: AWS Terrain Tiles / SRTM (открытые данные NASA/USGS).
- Декали, шейдер, скрипты: процедурные/оригинальные, ограничений нет.

См. также второй архив — пакет PBR-текстур «мрачная атмосфера»
(18 материалов CC0 + готовые StandardMaterial3D + демо-сцена).
Распакуйте его поверх этого (совмещается по путям `godot/…`).
